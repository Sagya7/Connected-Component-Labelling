#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <stdint.h>

// Namespace nullifies the use of cv::function();
using namespace std;
using namespace cv;

#define THRESHOLD   180
#define ERROR_INDEX (UINT_MAX - 1)
#define Width  320
#define Height 240
#define BufferSize (Width * Height)
#define FrequencyBufferSize (BufferSize / THRESHOLD)

#define NUMBEROFCOLORS 30

uint8_t color[NUMBEROFCOLORS][3] =
{
	{ 255, 0, 0 },{ 0, 255, 0 },{ 0, 0, 255 },
	{ 255, 255, 0 },{ 0, 255, 255 },{ 255, 0, 255 },
	{ 128, 128, 255 },{ 128, 128, 0 },{ 128, 0, 128 },
	{ 0, 128, 128 },{ 0, 0, 128 },{ 0, 128, 0 },
	{ 65, 128, 65 },{ 65, 65, 128 },{ 128, 65, 65 },
	{ 255, 30, 30 },{ 30, 255, 30 },{ 30, 30, 255 },
	{ 175, 255, 175 },{ 175, 175, 255 },{ 255, 175, 175 },
	{ 68, 200, 93 },{ 200, 68, 93 },{ 93, 68, 200 },
	{ 187, 214, 54 },{ 54, 214, 187 },{ 214, 187, 54 },
	{ 78, 60, 208 },{ 208, 78, 60 },{ 60, 208, 78 }
};

struct Node {
	uint32_t label;
	struct Node *parent;
	uint32_t nArea;
	uint32_t nAccSum;
	uint16_t nMinX;
	uint16_t nMaxX;
	uint16_t nMinY;
	uint16_t nMaxY;
	uint16_t nCentroidX;
	uint16_t nCentroidY;
	Node(uint32_t label) {
		this->label = label;
		this->parent = this;
		this->nArea = 0;
		this->nAccSum = 0;
		this->nMinX = 0;
		this->nMaxX = 0;
		this->nMinY = 0;
		this->nMaxY = 0;
		this->nCentroidX = 0;
		this->nCentroidY = 0;
	}
};

uint32_t LabeledImage[BufferSize];

Node* aLabels[BufferSize];

uint32_t aEquivalenceClass[BufferSize];

uint32_t aValidLabels[FrequencyBufferSize];
uint32_t nValidLabelIndex;

uint32_t nMaximumLabels = 0;

uint32_t GetWest(uint32_t nCurrPos, uint16_t nWidth)
{
	if (nCurrPos % nWidth == 0)
	{
		return ERROR_INDEX;
	}
	return (nCurrPos - 1);
}

uint32_t GetNorth(uint32_t nCurrPos, uint16_t nWidth)
{
	if (nCurrPos / nWidth == 0)
	{
		return ERROR_INDEX;
	}
	return (nCurrPos - nWidth);
}

void AddLabel(uint32_t nCurrLabel)
{
	Node* nNewLabel = new Node(nCurrLabel);
	aLabels[nCurrLabel] = nNewLabel;
}

Node *FindRep(Node *n)
{
	while (n->parent != n)
	{
		n = n->parent;
	}
	return n;
}

void Union(uint32_t nLower, uint32_t nHeigher)
{
	Node* x = aLabels[nLower];
	Node* y = aLabels[nHeigher];

	Node* xRep = FindRep(x);
	Node* yRep = FindRep(y);
	if (xRep->label < yRep->label)
	{
		if (xRep->nMinX > yRep->nMinX) xRep->nMinX = yRep->nMinX;
		if (xRep->nMaxX < yRep->nMaxX) xRep->nMaxX = yRep->nMaxX;
		if (xRep->nMinY > yRep->nMinY) xRep->nMinY = yRep->nMinY;
		if (xRep->nMaxY < yRep->nMaxY) xRep->nMaxY = yRep->nMaxY;
		aLabels[xRep->label]->nAccSum = aLabels[xRep->label]->nAccSum + aLabels[yRep->label]->nAccSum;
		aLabels[xRep->label]->nArea   = aLabels[xRep->label]->nArea   + aLabels[yRep->label]->nArea;
		if (aLabels[xRep->label]->nArea > THRESHOLD)
		{
			for (int u = 0; u < nValidLabelIndex; u++)
			{
				if (yRep->label != aValidLabels[u]) continue;
				aValidLabels[u] = xRep->label;
			}
		}
		yRep->parent = xRep;
	}
	else if(xRep->label > yRep->label)
	{
		if (yRep->nMinX > xRep->nMinX) yRep->nMinX = xRep->nMinX;
		if (yRep->nMaxX < xRep->nMaxX) yRep->nMaxX = xRep->nMaxX;
		if (yRep->nMinY > xRep->nMinY) yRep->nMinY = xRep->nMinY;
		if (yRep->nMaxY < xRep->nMaxY) yRep->nMaxY = xRep->nMaxY;
		aLabels[yRep->label]->nAccSum = aLabels[yRep->label]->nAccSum + aLabels[xRep->label]->nAccSum;
		aLabels[yRep->label]->nArea   = aLabels[yRep->label]->nArea   + aLabels[xRep->label]->nArea;
		if (aLabels[yRep->label]->nArea > THRESHOLD)
		{
			for (int u = 0; u < nValidLabelIndex; u++)
			{
				if (xRep->label != aValidLabels[u]) continue;
				aValidLabels[u] = yRep->label;
			}
		}
		xRep->parent = yRep;
	}
}

void DrawOutput(uint16_t nWidth, uint16_t nHeight, uint8_t* pOutput)
{
	uint32_t index = 0;
	bool     flag = false;
	for (uint16_t y = 0; y < nHeight; y++)
	{
		for (uint16_t x = 0; x < nWidth; x++)
		{
			index = x + y * nWidth;
			for (int j = 1; j < nValidLabelIndex; j++)
			{
				if (LabeledImage[index] != aValidLabels[j]) continue;
				pOutput[index * 3] = color[(j - 1) % NUMBEROFCOLORS][0];
				pOutput[(index * 3) + 1] = color[(j - 1) % NUMBEROFCOLORS][1];
				pOutput[(index * 3) + 2] = color[(j - 1) % NUMBEROFCOLORS][2];
				flag = true;
				break;
			}
			if (flag != true)
			{
				pOutput[index * 3] = 0;
				pOutput[(index * 3) + 1] = 0;
				pOutput[(index * 3) + 2] = 0;
			}
			flag = false;
		}
	}

	int s = nValidLabelIndex;
	for (int m = 1; m < nValidLabelIndex; m++)
	{
		int w = 0;
		for (w = (aLabels[aValidLabels[m]]->nMinX + aLabels[aValidLabels[m]]->nMinY * nWidth) * 3; w <= (aLabels[aValidLabels[m]]->nMaxX + aLabels[aValidLabels[m]]->nMinY * nWidth) * 3;)
		{
			pOutput[w++] = color[s % NUMBEROFCOLORS][0];
			pOutput[w++] = color[s % NUMBEROFCOLORS][1];
			pOutput[w++] = color[s % NUMBEROFCOLORS][2];
		}
		for (int h = (aLabels[aValidLabels[m]]->nMaxX + aLabels[aValidLabels[m]]->nMinY * nWidth) * 3; h <= (aLabels[aValidLabels[m]]->nMaxX + aLabels[aValidLabels[m]]->nMaxY * nWidth) * 3;)
		{
			pOutput[h++] = color[s % NUMBEROFCOLORS][0];
			pOutput[h++] = color[s % NUMBEROFCOLORS][1];
			pOutput[h++] = color[s % NUMBEROFCOLORS][2];
			h = h + ((nWidth - 1) * 3);
		}
		for (int h = (aLabels[aValidLabels[m]]->nMaxX + aLabels[aValidLabels[m]]->nMaxY * nWidth) * 3; h >= (aLabels[aValidLabels[m]]->nMinX + aLabels[aValidLabels[m]]->nMaxY * nWidth) * 3;)
		{
			pOutput[h++] = color[s % NUMBEROFCOLORS][0];
			pOutput[h++] = color[s % NUMBEROFCOLORS][1];
			pOutput[h++] = color[s % NUMBEROFCOLORS][2];
			h = h - 6;
		}
		for (int h = (aLabels[aValidLabels[m]]->nMinX + aLabels[aValidLabels[m]]->nMaxY * nWidth) * 3; h >= (aLabels[aValidLabels[m]]->nMinX + aLabels[aValidLabels[m]]->nMinY * nWidth) * 3;)
		{
			pOutput[h++] = color[s % NUMBEROFCOLORS][0];
			pOutput[h++] = color[s % NUMBEROFCOLORS][1];
			pOutput[h++] = color[s % NUMBEROFCOLORS][2];
			h = h - ((nWidth + 1) * 3);
		}
		s++;
	}
}

void EliminateRepeatedindexes()
{
	uint32_t nActualValidIndex = 0;
	for (uint32_t i = 0; i < nValidLabelIndex; i++)
	{
		uint32_t j;
		for (j = 0; j < nActualValidIndex; j++)
		{
			if (aValidLabels[i] == aValidLabels[j])
				break;
		}
		if (j == nActualValidIndex)
		{
			aValidLabels[nActualValidIndex] = aValidLabels[i];
			nActualValidIndex++;
		}
	}
	for (uint32_t i = nActualValidIndex; i < nValidLabelIndex; i++)
	{
		aValidLabels[i] = UINT32_MAX;
	}
	nValidLabelIndex = nActualValidIndex;
}

void FirstPass(uint16_t nWidth, uint16_t nHeight, uint8_t* pInput)
{
	uint32_t  nCurrPos, nLeftPos, nUpPos, nCurrLabel = 0;
	uint8_t nCurr, nLeft, nUp;
	uint8_t thresholdhorizontal = 5;
	uint8_t thresholdvertical = 5;
	for (uint16_t i = 0; i < nHeight; i++)
	{
		for (uint16_t j = 0; j < nWidth; j++)
		{
			if (i == 0 && j == 0)
			{
				aLabels[nCurrLabel]->nArea++;
				continue;
			}
			nCurrPos = j + (i * nWidth);
			nCurr = pInput[nCurrPos];
			nLeftPos = GetWest(nCurrPos, nWidth);
			uint32_t aMatch[2] = { ERROR_INDEX, ERROR_INDEX };
			bool bMatched = false;
			if (nLeftPos != ERROR_INDEX)
			{
				nLeft = pInput[nLeftPos];
				if (nLeft > thresholdhorizontal)
				{
					if ((nCurr >= (nLeft - thresholdhorizontal)) && (nCurr <= (nLeft + thresholdhorizontal)))
					{
						aMatch[0] = LabeledImage[nLeftPos];
						bMatched = true;
					}
				}
				else
				{
					if ((nCurr <= (nLeft + thresholdhorizontal)))
					{
						aMatch[0] = LabeledImage[nLeftPos];
						bMatched = true;
					}
				}
			}

			nUpPos = GetNorth(nCurrPos, nWidth);
			if (nUpPos != ERROR_INDEX)
			{
				nUp = pInput[nUpPos];
				if (nUp > thresholdvertical)
				{
					if ((nCurr >= (nUp - thresholdvertical)) && (nCurr <= (nUp + thresholdvertical)))
					{
						aMatch[1] = LabeledImage[nUpPos];
						bMatched = true;
					}
				}
				else
				{
					if ((nCurr <= nUp + thresholdvertical))
					{
						aMatch[1] = LabeledImage[nUpPos];
						bMatched = true;
					}
				}
			}

			if (bMatched == false)
			{
				LabeledImage[nCurrPos] = ++nCurrLabel;
				AddLabel(nCurrLabel);
				aLabels[LabeledImage[nCurrPos]]->nAccSum = pInput[nCurrPos];
				aLabels[LabeledImage[nCurrPos]]->nArea++;
				aLabels[LabeledImage[nCurrPos]]->nMinX = j;
				aLabels[LabeledImage[nCurrPos]]->nMinY = i;
				aLabels[LabeledImage[nCurrPos]]->nMaxX = j;
				aLabels[LabeledImage[nCurrPos]]->nMaxY = i;
			}
			else
			{
				uint32_t temp;
				if (aMatch[0] > aMatch[1])
				{
					temp = aMatch[0];
					aMatch[0] = aMatch[1];
					aMatch[1] = temp;
				}
				uint32_t ref = aMatch[0];
				LabeledImage[nCurrPos] = ref;
				if (aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nMaxX < j) aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nMaxX = j;
				if (aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nMaxY < i) aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nMaxY = i;
				aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nAccSum = aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nAccSum + pInput[nCurrPos];
				aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nArea++;
				if (aLabels[FindRep(aLabels[LabeledImage[nCurrPos]])->label]->nArea > THRESHOLD)
				{
					if (nValidLabelIndex == 0)
					{
						aValidLabels[nValidLabelIndex] = FindRep(aLabels[LabeledImage[nCurrPos]])->label;
						nValidLabelIndex++;
					}
					bool flag = false;
					for (int i = 0; i < nValidLabelIndex; i++)
					{
						if (aValidLabels[i] != FindRep(aLabels[LabeledImage[nCurrPos]])->label) continue;
						flag = true;
					}
					if (flag == false)
					{
						aValidLabels[nValidLabelIndex] = FindRep(aLabels[LabeledImage[nCurrPos]])->label;
						nValidLabelIndex++;
					}
				}
				if (aMatch[1] != ERROR_INDEX)
				{
					if (aMatch[0] != aMatch[1])
					{
						Union(aMatch[0], aMatch[1]);

					}
				}
			}
		}
	}
	nMaximumLabels = nCurrLabel;

	EliminateRepeatedindexes();
}

void SecondPass(uint16_t nWidth, uint16_t nHeight)
{
	for (int i = 0; i <= nMaximumLabels; i++)
	{
		aEquivalenceClass[i] = FindRep(aLabels[i])->label;
	}

	//secondpass
	for (int i = 0; i < nHeight; ++i)
	{
		for (int j = 0; j < nWidth; ++j)
		{
			LabeledImage[i * nWidth + j] = aEquivalenceClass[LabeledImage[i * nWidth + j]];
		}
	}
}

void Labeltheimage(uint16_t nWidth, uint16_t nHeight, uint8_t* pInput, uint8_t* pOutput)
{
	AddLabel(0);

	FirstPass(nWidth, nHeight, pInput);

	//it relabels the equivalent labels, position of people is not calculated here.
	SecondPass(nWidth, nHeight);

	DrawOutput(nWidth, nHeight, pOutput);
}


int main()
{
	uint32_t H = 240;
	uint32_t W = 320;
	Mat input(H, W, CV_8UC1);
	Mat output(H, W, CV_8UC3);

	// Set all pixel values to 0
	input  = cv::Scalar::all(0);
	output = cv::Scalar::all(0);

	memset(aValidLabels, UINT8_MAX, FrequencyBufferSize * sizeof(uint32_t));

	input = imread("3PeopleDepth2.png", 0);

	Labeltheimage(W,H,input.data,output.data);

	imshow("Output Image", output);
	
	waitKey(10000);

	return 0;

}